<?php
class TutorialAppModel extends AppModel{
    public $tablePrefix = 'tutorial__';
}